# AIFailGuard 🛡️

**Enterprise AI Model Monitoring & Anomaly Detection Dashboard**

---

## 🎯 Overview

AIFailGuard is a full-featured, enterprise-grade dashboard for monitoring AI model outputs in real-time. It detects anomalies using statistical thresholds, fires red-flag alerts, visualizes performance over time, and simulates email notifications — all from a modern, mobile-responsive dark UI.

---

## ✅ Implemented Features

### Core Monitoring
- **Live Dashboard** with KPI cards (Active Models, Avg Accuracy, Anomalies, Active Alerts, Avg Latency)
- **Risk Gauge** — SVG-based Low / Medium / High risk indicator with per-model breakdown bars
- **Anomaly Detection** — Statistical threshold engine classifying outputs as: `normal`, `anomaly`, `critical`
- **Automatic Risk Classification** — `Low` / `Medium` / `High` per output and per model aggregate

### Charts & Visualizations
- **Accuracy Over Time** — Line chart per model (filterable by model)
- **Latency Chart** — Bar chart with color-coded threshold violations (red = exceeded)
- **Error Rate Chart** — Area line chart with per-point coloring
- **Status Distribution** — Doughnut chart showing Normal / Anomaly / Critical ratios

### Alert System (Red Flag)
- **Alert Center** — Full list of fired alerts with severity badges
- **Severity Levels**: Critical 🚨 / High 🔴 / Medium 🟠 / Low 🟡
- **Email Simulation** — Modal showing simulated email alert with full details
- **Alert Acknowledgement** — Per-alert and bulk "Ack All"
- **Manual Alert Simulation** — Trigger random alert on demand

### Model Outputs
- **Manual Entry Form** — Submit individual model outputs with all metrics
- **File Upload** — Import `.json` or `.csv` batch files with drag-and-drop
- **Live Stream Simulator** — Generates real-time AI output stream with configurable anomaly injection rate

### Logs
- **Full Output Log Table** — All recorded outputs with timestamp, model, accuracy, latency, error rate, confidence, status, risk, raw output
- **Filters** — By model and by status (normal / anomaly / critical)

### Configuration
- **Threshold Settings** — Configurable sliders for:
  - Minimum Accuracy threshold
  - Maximum Latency threshold
  - Maximum Error Rate threshold
  - Minimum Confidence threshold
- **Email Alert Config** — Email address, frequency, minimum severity, enable/disable toggle

### Other
- **System Scan Modal** — Animated full-system scan with step progress
- **Export Report** — Downloads JSON report with system risk, model breakdowns, alert counts
- **Toast Notification System** — Success / Warning / Error / Info notifications
- **Fully Responsive** — Mobile-friendly sidebar with hamburger menu, adaptive grid layouts

---

## 📁 File Structure

```
index.html          → Main application shell (all pages)
css/
  style.css         → Full enterprise dark-theme CSS
js/
  app.js            → All application logic (anomaly detection, charts, API, stream)
```

---

## 🔌 API Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `tables/model_outputs` | GET | Load all model output records |
| `tables/model_outputs` | POST | Submit new model output |
| `tables/alerts` | GET | Load all alerts |
| `tables/alerts` | POST | Create a new alert |
| `tables/alerts/:id` | PATCH | Acknowledge an alert |

---

## 📊 Data Models

### `model_outputs`
| Field | Type | Description |
|-------|------|-------------|
| id | text | UUID |
| model_name | text | AI model name |
| accuracy | number | 0–100 accuracy score |
| latency | number | Response time in ms |
| error_rate | number | Error percentage |
| confidence | number | Confidence 0.0–1.0 |
| output_value | number | Primary numeric output |
| status | text | normal / anomaly / critical |
| risk_level | text | Low / Medium / High |
| alert_sent | bool | Whether alert was triggered |
| raw_output | text | Raw JSON/text model output |
| timestamp | datetime | Output timestamp |

### `alerts`
| Field | Type | Description |
|-------|------|-------------|
| id | text | UUID |
| alert_type | text | anomaly / critical_failure / threshold_breach / system_error |
| model_name | text | Associated model |
| message | text | Alert message |
| severity | text | Low / Medium / High / Critical |
| email_to | text | Simulated email recipient |
| acknowledged | bool | Whether alert was acknowledged |
| timestamp | datetime | Alert creation time |

---

## 🧠 Anomaly Detection Logic

```
CRITICAL if:
  accuracy < (minAccuracy - 20)  OR
  error_rate > (maxErrorRate + 15)  OR
  latency > (maxLatency + 800)  OR
  confidence < (minConfidence - 0.25)

ANOMALY if:
  accuracy < minAccuracy  OR
  error_rate > maxErrorRate  OR
  latency > maxLatency  OR
  confidence < minConfidence

NORMAL otherwise
```

**Default Thresholds:**
- Min Accuracy: 80%
- Max Latency: 1000ms
- Max Error Rate: 15%
- Min Confidence: 0.60

---

## 🚀 Navigation

| Page | Path | Description |
|------|------|-------------|
| Dashboard | `#dashboard` | Main overview with KPIs and charts |
| Models | `#models` | Per-model performance cards |
| Alerts | `#alerts` | Full alert center |
| Logs | `#logs` | Filterable output log table |
| Upload/Stream | `#upload` | Data ingestion (manual/file/stream) |
| Thresholds | `#settings` | Configure detection parameters |

---

## 🔮 Recommended Next Steps

1. **Authentication** — Add user login with role-based access (admin, viewer)
2. **Real-time WebSocket** — Replace polling with true push updates from model inference servers
3. **Supabase Integration** — Persist data in Supabase with real-time subscriptions
4. **Model API Integration** — Direct HTTP hook endpoints to receive outputs from running models
5. **Advanced Anomaly Detection** — Z-score, IQR, LSTM-based outlier detection
6. **Alert Escalation** — Multi-tier escalation chains (email → SMS → PagerDuty)
7. **Comparative Analysis** — Side-by-side model benchmarking view
8. **Custom Dashboards** — Drag-and-drop widget layout configuration
9. **SLA Monitoring** — Service Level Agreement violation tracking
10. **Audit Logs** — Full audit trail of configuration changes

---

## 🛠️ Tech Stack

- **HTML5** / **CSS3** / **Vanilla JavaScript (ES2022)**
- **Chart.js 4.4** — Charting library
- **Font Awesome 6.4** — Icon library
- **Google Fonts (Inter + JetBrains Mono)** — Typography
- **RESTful Table API** — Data persistence layer

---

*AIFailGuard — Built for enterprise AI reliability teams*
