/* ===================================================
   AIFailGuard — Main Application JS
   =================================================== */

// ─── STATE ───────────────────────────────────────────
const STATE = {
  outputs: [],
  alerts: [],
  thresholds: {
    minAccuracy:   80,
    maxLatency:    1000,
    maxErrorRate:  15,
    minConfidence: 0.6,
  },
  alertEmail: 'admin@enterprise.com',
  currentPage: 'dashboard',
  charts: {},
  streamTimer: null,
  isRefreshing: false,
};

// ─── PAGE TITLES ─────────────────────────────────────
const PAGE_TITLES = {
  dashboard: 'Dashboard',
  models:    'AI Models',
  alerts:    'Alert Center',
  logs:      'Output Logs',
  upload:    'Upload / Stream',
  settings:  'Thresholds',
};

// ─── INIT ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  setupNav();
  setupSidebar();
  await loadAllData();
  renderDashboard();
  initCharts();
  renderModelsPage();
  renderAlertsPage();
  renderLogsPage();
  updateNotifBadge();

  // drag-and-drop for upload zone
  const zone = document.getElementById('uploadZone');
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.style.borderColor = 'var(--blue)'; });
  zone.addEventListener('dragleave',  () => { zone.style.borderColor = ''; });
  zone.addEventListener('drop', e => { e.preventDefault(); zone.style.borderColor = ''; handleFileDrop(e); });
  zone.addEventListener('click', () => document.getElementById('fileInput').click());
});

// ─── NAV ─────────────────────────────────────────────
function setupNav() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      const page = item.dataset.page;
      switchPage(page);
      if (window.innerWidth <= 768) closeSidebar();
    });
  });
}

function switchPage(page) {
  STATE.currentPage = page;
  document.querySelectorAll('.nav-item').forEach(i => i.classList.toggle('active', i.dataset.page === page));
  document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.id === `page-${page}`));
  document.getElementById('breadcrumb').textContent = PAGE_TITLES[page] || page;

  if (page === 'dashboard') { renderDashboard(); updateCharts(); }
  if (page === 'models')    renderModelsPage();
  if (page === 'alerts')    renderAlertsPage();
  if (page === 'logs')      renderLogsPage();
}

// ─── SIDEBAR ─────────────────────────────────────────
function setupSidebar() {
  document.getElementById('menuToggle').addEventListener('click', openSidebar);
  document.getElementById('sidebarClose').addEventListener('click', closeSidebar);
  document.addEventListener('click', e => {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth <= 768 && sidebar.classList.contains('open') &&
        !sidebar.contains(e.target) && !document.getElementById('menuToggle').contains(e.target)) {
      closeSidebar();
    }
  });
}
function openSidebar()  { document.getElementById('sidebar').classList.add('open'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); }

// ─── DATA LOADING ─────────────────────────────────────
async function loadAllData() {
  try {
    const [outputsRes, alertsRes] = await Promise.all([
      fetch('tables/model_outputs?limit=100&sort=created_at'),
      fetch('tables/alerts?limit=100&sort=created_at'),
    ]);
    const outputsData = await outputsRes.json();
    const alertsData  = await alertsRes.json();
    STATE.outputs = outputsData.data || [];
    STATE.alerts  = alertsData.data  || [];
  } catch (err) {
    showToast('error', 'Data Load Error', 'Could not fetch monitoring data.');
    console.error(err);
  }
}

// ─── REFRESH ─────────────────────────────────────────
async function refreshAll() {
  if (STATE.isRefreshing) return;
  STATE.isRefreshing = true;
  const icon = document.getElementById('refreshIcon');
  icon.classList.add('fa-spin');
  await loadAllData();
  renderDashboard();
  updateCharts();
  renderModelsPage();
  renderAlertsPage();
  renderLogsPage();
  updateNotifBadge();
  icon.classList.remove('fa-spin');
  STATE.isRefreshing = false;
  showToast('success', 'Refreshed', 'All data updated successfully.');
}

// ─── ANOMALY DETECTION ───────────────────────────────
function detectStatus(row) {
  const t = STATE.thresholds;
  if (row.accuracy < t.minAccuracy - 20 || row.error_rate > t.maxErrorRate + 15 ||
      row.latency > t.maxLatency + 800   || row.confidence < t.minConfidence - 0.25) {
    return 'critical';
  }
  if (row.accuracy < t.minAccuracy || row.error_rate > t.maxErrorRate ||
      row.latency > t.maxLatency   || row.confidence < t.minConfidence) {
    return 'anomaly';
  }
  return 'normal';
}

function computeRisk(row) {
  const status = detectStatus(row);
  if (status === 'critical') return 'High';
  if (status === 'anomaly')  return 'Medium';
  return 'Low';
}

function computeSystemRisk(outputs) {
  if (!outputs.length) return { level: 'Low', score: 0 };
  const highCount   = outputs.filter(o => computeRisk(o) === 'High').length;
  const medCount    = outputs.filter(o => computeRisk(o) === 'Medium').length;
  const totalWeight = highCount * 3 + medCount * 1;
  const score = Math.min(100, Math.round((totalWeight / (outputs.length * 3)) * 100));
  let level = 'Low';
  if (score >= 60) level = 'High';
  else if (score >= 25) level = 'Medium';
  return { level, score };
}

// ─── DASHBOARD ───────────────────────────────────────
function renderDashboard() {
  const outputs = STATE.outputs;
  if (!outputs.length) return;

  // KPIs
  const models = [...new Set(outputs.map(o => o.model_name))];
  const avgAcc = avg(outputs.map(o => o.accuracy));
  const anomalies = outputs.filter(o => detectStatus(o) !== 'normal').length;
  const activeAlerts = STATE.alerts.filter(a => !a.acknowledged).length;
  const avgLat = avg(outputs.map(o => o.latency));

  document.getElementById('kpiModels').textContent   = models.length;
  document.getElementById('kpiAccuracy').textContent = avgAcc.toFixed(1) + '%';
  document.getElementById('kpiAnomalies').textContent = anomalies;
  document.getElementById('kpiAlerts').textContent   = activeAlerts;
  document.getElementById('kpiLatency').textContent  = Math.round(avgLat) + 'ms';
  document.getElementById('alertBadge').textContent  = activeAlerts;
  document.getElementById('modelCount').textContent  = models.length;

  const accTrend = document.getElementById('kpiAccuracyTrend');
  accTrend.textContent = avgAcc >= 85 ? '✓ Healthy' : '⚠ Below target';
  accTrend.className   = 'kpi-trend ' + (avgAcc >= 85 ? 'up' : 'down');

  const anomTrend = document.getElementById('kpiAnomalyTrend');
  anomTrend.textContent = anomalies > 0 ? `${anomalies} need review` : 'None detected';
  anomTrend.className   = 'kpi-trend ' + (anomalies > 0 ? 'down' : 'up');

  // Risk gauge
  renderRiskGauge(outputs, models);

  // Fill model filter dropdowns
  fillModelFilter('accuracyModelFilter', models);
  fillModelFilter('logModelFilter', models);

  // Recent alerts
  renderRecentAlerts();
}

function fillModelFilter(id, models) {
  const sel = document.getElementById(id);
  const current = sel.value;
  sel.innerHTML = '<option value="all">All Models</option>';
  models.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m; opt.textContent = m;
    if (m === current) opt.selected = true;
    sel.appendChild(opt);
  });
}

// ─── RISK GAUGE ──────────────────────────────────────
function renderRiskGauge(outputs, models) {
  const { level, score } = computeSystemRisk(outputs);

  // Rotate needle: Low=−70°, Med=0°, High=+70°
  const angle = -70 + (score / 100) * 140;
  const needle = document.getElementById('gaugeNeedle');
  if (needle) needle.setAttribute('transform', `rotate(${angle}, 100, 100)`);

  const label = document.getElementById('gaugeLabel');
  if (label) label.textContent = level;

  const badge = document.getElementById('riskBadge');
  const icons = { Low: 'fa-check-circle', Medium: 'fa-exclamation-circle', High: 'fa-skull-crossbones' };
  badge.className = `risk-badge ${level.toLowerCase()}`;
  badge.innerHTML = `<i class="fas ${icons[level] || 'fa-info'}"></i> <span>${level} Risk — Score ${score}/100</span>`;

  const desc = document.getElementById('riskDesc');
  const descs = {
    Low:    'All models operating within acceptable parameters.',
    Medium: 'Some models showing degraded performance. Review recommended.',
    High:   'Critical anomalies detected. Immediate action required.',
  };
  desc.textContent = descs[level];

  // Per-model mini bars
  const list = document.getElementById('modelRiskList');
  list.innerHTML = '';
  models.forEach(m => {
    const mOutputs = outputs.filter(o => o.model_name === m);
    const mRisk = computeSystemRisk(mOutputs);
    const colors = { Low: 'var(--green)', Medium: 'var(--orange)', High: 'var(--red)' };
    const color = colors[mRisk.level] || 'var(--blue)';
    list.innerHTML += `
      <div class="model-risk-row">
        <span class="model-risk-name">${m}</span>
        <div class="model-risk-bar-wrap">
          <div class="model-risk-bar" style="width:${mRisk.score}%;background:${color}"></div>
        </div>
        <span class="model-risk-pct" style="color:${color}">${mRisk.level}</span>
      </div>`;
  });
}

// ─── RECENT ALERTS ────────────────────────────────────
function renderRecentAlerts() {
  const list = document.getElementById('recentAlertsList');
  const recent = [...STATE.alerts].reverse().slice(0, 5);
  if (!recent.length) {
    list.innerHTML = '<div class="empty-state"><i class="fas fa-check-circle"></i><p>No active alerts</p></div>';
    return;
  }
  list.innerHTML = recent.map(a => {
    const sev  = (a.severity || 'Low').toLowerCase();
    const icon = severityIcon(a.severity);
    const ts   = a.created_at ? new Date(a.created_at).toLocaleString() : '—';
    return `
      <div class="alert-mini-item ${sev}">
        <span class="alert-flag">${icon}</span>
        <div class="alert-mini-body">
          <div class="alert-mini-msg">${a.message || 'Alert'}</div>
          <div class="alert-mini-meta">${a.model_name} · ${ts}</div>
        </div>
        <span class="alert-mini-badge badge-${sev}">${a.severity}</span>
      </div>`;
  }).join('');
}

// ─── CHARTS ──────────────────────────────────────────
const CHART_COLORS = {
  'GPT-4-Turbo':  '#3b82f6',
  'Llama-3-70B':  '#a855f7',
  'Claude-3-Opus':'#22c55e',
  'Mistral-7B':   '#f59e0b',
  'default':      '#14b8a6',
};
function getModelColor(name) { return CHART_COLORS[name] || CHART_COLORS.default; }

const CHART_DEFAULTS = {
  color: '#7ca3d6',
  plugins: {
    legend: { labels: { color: '#7ca3d6', font: { family: 'Inter', size: 11 }, boxWidth: 12 } },
    tooltip: {
      backgroundColor: '#0c1629', titleColor: '#e8f0fe', bodyColor: '#7ca3d6',
      borderColor: '#1e3050', borderWidth: 1, cornerRadius: 8,
    },
  },
  scales: {
    x: { ticks: { color: '#3d5a87', font: { size: 10 } }, grid: { color: '#1e3050' } },
    y: { ticks: { color: '#3d5a87', font: { size: 10 } }, grid: { color: '#1e3050' } },
  },
};

function initCharts() {
  const outputs = STATE.outputs;
  const models  = [...new Set(outputs.map(o => o.model_name))];

  // ── Accuracy Chart ──
  const accCtx = document.getElementById('accuracyChart').getContext('2d');
  const labels = outputs.map((_, i) => `#${i + 1}`);
  const accDatasets = models.map(m => ({
    label: m,
    data: outputs.map(o => o.model_name === m ? o.accuracy : null),
    borderColor: getModelColor(m),
    backgroundColor: hexToRgba(getModelColor(m), 0.1),
    borderWidth: 2, tension: 0.4, fill: false,
    pointRadius: 3, pointHoverRadius: 6,
    spanGaps: true,
  }));
  STATE.charts.accuracy = new Chart(accCtx, {
    type: 'line',
    data: { labels, datasets: accDatasets },
    options: {
      ...CHART_DEFAULTS,
      responsive: true, maintainAspectRatio: false,
      plugins: {
        ...CHART_DEFAULTS.plugins,
        annotation: {},
      },
      scales: {
        ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, min: 40, max: 100,
             ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v => v + '%' } },
      },
    },
  });

  // ── Latency Chart ──
  const latCtx = document.getElementById('latencyChart').getContext('2d');
  STATE.charts.latency = new Chart(latCtx, {
    type: 'bar',
    data: {
      labels: outputs.map((_, i) => `#${i + 1}`),
      datasets: [{
        label: 'Latency (ms)',
        data: outputs.map(o => o.latency),
        backgroundColor: outputs.map(o =>
          o.latency > STATE.thresholds.maxLatency ? 'rgba(239,68,68,.7)' : 'rgba(59,130,246,.5)'),
        borderRadius: 4,
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      responsive: true, maintainAspectRatio: false,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      scales: { ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v => v + 'ms' } },
      },
    },
  });

  // ── Error Rate Chart ──
  const errCtx = document.getElementById('errorRateChart').getContext('2d');
  STATE.charts.errorRate = new Chart(errCtx, {
    type: 'line',
    data: {
      labels: outputs.map((_, i) => `#${i + 1}`),
      datasets: [{
        label: 'Error Rate %',
        data: outputs.map(o => o.error_rate),
        borderColor: 'var(--red)',
        backgroundColor: 'rgba(239,68,68,.1)',
        fill: true, tension: 0.4, borderWidth: 2,
        pointRadius: 3, pointHoverRadius: 6,
        pointBackgroundColor: outputs.map(o =>
          o.error_rate > STATE.thresholds.maxErrorRate ? '#ef4444' : '#3b82f6'),
      }],
    },
    options: {
      ...CHART_DEFAULTS,
      responsive: true, maintainAspectRatio: false,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
      scales: { ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks: { ...CHART_DEFAULTS.scales.y.ticks, callback: v => v + '%' } },
      },
    },
  });

  // ── Status Distribution ──
  const stCtx = document.getElementById('statusChart').getContext('2d');
  const normalCount   = outputs.filter(o => detectStatus(o) === 'normal').length;
  const anomalyCount  = outputs.filter(o => detectStatus(o) === 'anomaly').length;
  const criticalCount = outputs.filter(o => detectStatus(o) === 'critical').length;
  STATE.charts.status = new Chart(stCtx, {
    type: 'doughnut',
    data: {
      labels: ['Normal', 'Anomaly', 'Critical'],
      datasets: [{
        data: [normalCount, anomalyCount, criticalCount],
        backgroundColor: ['rgba(34,197,94,.7)', 'rgba(245,158,11,.7)', 'rgba(239,68,68,.7)'],
        borderColor: ['#22c55e','#f59e0b','#ef4444'],
        borderWidth: 2,
        hoverOffset: 6,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { color: '#7ca3d6', font: { size: 11 }, padding: 12 } },
        tooltip: CHART_DEFAULTS.plugins.tooltip,
      },
      cutout: '60%',
    },
  });
}

function updateCharts() {
  const outputs = STATE.outputs;
  const models  = [...new Set(outputs.map(o => o.model_name))];

  if (STATE.charts.accuracy) {
    const filter = document.getElementById('accuracyModelFilter')?.value || 'all';
    const filtered = filter === 'all' ? outputs : outputs.filter(o => o.model_name === filter);
    const filteredModels = filter === 'all' ? models : [filter];
    STATE.charts.accuracy.data.labels = filtered.map((_, i) => `#${i + 1}`);
    STATE.charts.accuracy.data.datasets = filteredModels.map(m => ({
      label: m,
      data: filtered.map(o => o.model_name === m ? o.accuracy : null),
      borderColor: getModelColor(m), backgroundColor: hexToRgba(getModelColor(m), 0.1),
      borderWidth: 2, tension: 0.4, fill: false, pointRadius: 3, spanGaps: true,
    }));
    STATE.charts.accuracy.update();
  }

  if (STATE.charts.latency) {
    STATE.charts.latency.data.labels = outputs.map((_, i) => `#${i + 1}`);
    STATE.charts.latency.data.datasets[0].data = outputs.map(o => o.latency);
    STATE.charts.latency.data.datasets[0].backgroundColor = outputs.map(o =>
      o.latency > STATE.thresholds.maxLatency ? 'rgba(239,68,68,.7)' : 'rgba(59,130,246,.5)');
    STATE.charts.latency.update();
  }

  if (STATE.charts.errorRate) {
    STATE.charts.errorRate.data.labels = outputs.map((_, i) => `#${i + 1}`);
    STATE.charts.errorRate.data.datasets[0].data = outputs.map(o => o.error_rate);
    STATE.charts.errorRate.update();
  }

  if (STATE.charts.status) {
    STATE.charts.status.data.datasets[0].data = [
      outputs.filter(o => detectStatus(o) === 'normal').length,
      outputs.filter(o => detectStatus(o) === 'anomaly').length,
      outputs.filter(o => detectStatus(o) === 'critical').length,
    ];
    STATE.charts.status.update();
  }
}

function updateAccuracyChart() { updateCharts(); }

// ─── MODELS PAGE ─────────────────────────────────────
function renderModelsPage() {
  const outputs = STATE.outputs;
  const models  = [...new Set(outputs.map(o => o.model_name))];
  const grid = document.getElementById('modelCardsGrid');

  if (!models.length) {
    grid.innerHTML = '<div class="empty-state"><i class="fas fa-robot"></i><p>No model data</p></div>';
    return;
  }

  grid.innerHTML = models.map(m => {
    const mOutputs = outputs.filter(o => o.model_name === m);
    const mAcc = avg(mOutputs.map(o => o.accuracy));
    const mLat = avg(mOutputs.map(o => o.latency));
    const mErr = avg(mOutputs.map(o => o.error_rate));
    const mConf = avg(mOutputs.map(o => o.confidence));
    const risk = computeSystemRisk(mOutputs);
    const riskColors = { Low: 'var(--green)', Medium: 'var(--orange)', High: 'var(--red)' };
    const rColor = riskColors[risk.level] || 'var(--blue)';
    const anomCount = mOutputs.filter(o => detectStatus(o) !== 'normal').length;
    return `
      <div class="model-card">
        <div class="model-card-header">
          <div>
            <div class="model-card-name">${m}</div>
            <div class="model-card-sub">${mOutputs.length} outputs recorded</div>
          </div>
          <span class="risk-pill ${risk.level}">${risk.level} Risk</span>
        </div>
        <div class="model-stats">
          <div class="model-stat-item">
            <div class="model-stat-label">Accuracy</div>
            <div class="model-stat-val ${mAcc < STATE.thresholds.minAccuracy ? 'bad' : ''}">${mAcc.toFixed(1)}%</div>
          </div>
          <div class="model-stat-item">
            <div class="model-stat-label">Avg Latency</div>
            <div class="model-stat-val ${mLat > STATE.thresholds.maxLatency ? 'warn' : ''}">${Math.round(mLat)}ms</div>
          </div>
          <div class="model-stat-item">
            <div class="model-stat-label">Error Rate</div>
            <div class="model-stat-val ${mErr > STATE.thresholds.maxErrorRate ? 'bad' : ''}">${mErr.toFixed(1)}%</div>
          </div>
          <div class="model-stat-item">
            <div class="model-stat-label">Confidence</div>
            <div class="model-stat-val ${mConf < STATE.thresholds.minConfidence ? 'warn' : ''}">${mConf.toFixed(2)}</div>
          </div>
        </div>
        <div class="model-perf-bar">
          <div class="perf-label">
            <span>Health Score</span>
            <span style="color:${rColor}">${100 - risk.score}%</span>
          </div>
          <div class="perf-track">
            <div class="perf-fill" style="width:${100-risk.score}%;background:${rColor}"></div>
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:12px;font-size:12px;color:var(--text-muted)">
          <span><i class="fas fa-triangle-exclamation" style="color:var(--orange)"></i> ${anomCount} anomalies</span>
          <span><i class="fas fa-check-circle" style="color:var(--green)"></i> ${mOutputs.length - anomCount} normal</span>
        </div>
      </div>`;
  }).join('');
}

// ─── ALERTS PAGE ─────────────────────────────────────
function renderAlertsPage() {
  const container = document.getElementById('alertsContainer');
  const alerts = [...STATE.alerts].reverse();

  if (!alerts.length) {
    container.innerHTML = '<div class="card"><div class="card-body"><div class="empty-state"><i class="fas fa-shield-check"></i><p>No alerts — all systems healthy</p></div></div></div>';
    return;
  }

  container.innerHTML = alerts.map(a => {
    const sev  = (a.severity || 'Low').toLowerCase();
    const icon = severityFAIcon(a.severity);
    const ts   = a.created_at ? new Date(a.created_at).toLocaleString() : '—';
    const ackClass = a.acknowledged ? 'acknowledged' : '';
    return `
      <div class="alert-card ${sev} ${ackClass}" id="alert-${a.id}">
        <div class="alert-card-icon"><i class="${icon}"></i></div>
        <div class="alert-card-body">
          <div class="alert-card-title">${alertTypeLabel(a.alert_type)} — ${a.model_name}</div>
          <div class="alert-card-msg">${a.message}</div>
          <div class="alert-card-meta">
            <span><i class="fas fa-clock"></i> ${ts}</span>
            <span><i class="fas fa-envelope"></i> ${a.email_to || '—'}</span>
            <span class="alert-mini-badge badge-${sev}">${a.severity}</span>
            ${a.acknowledged ? '<span style="color:var(--green)"><i class="fas fa-check-circle"></i> Acknowledged</span>' : ''}
          </div>
        </div>
        <div class="alert-card-actions">
          ${!a.acknowledged ? `<button class="btn-ack" onclick="acknowledgeAlert('${a.id}')"><i class="fas fa-check"></i> Ack</button>` : ''}
          <button class="btn btn-ghost btn-sm" onclick="resendEmail('${a.id}')"><i class="fas fa-paper-plane"></i></button>
        </div>
      </div>`;
  }).join('');
}

async function acknowledgeAlert(id) {
  try {
    await fetch(`tables/alerts/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ acknowledged: true }),
    });
    const a = STATE.alerts.find(x => x.id === id);
    if (a) a.acknowledged = true;
    renderAlertsPage();
    renderRecentAlerts();
    updateNotifBadge();
    showToast('success', 'Acknowledged', 'Alert marked as resolved.');
  } catch (err) {
    showToast('error', 'Error', 'Could not acknowledge alert.');
  }
}

async function acknowledgeAll() {
  const unacked = STATE.alerts.filter(a => !a.acknowledged);
  if (!unacked.length) { showToast('info', 'All clear', 'No unacknowledged alerts.'); return; }
  for (const a of unacked) {
    await fetch(`tables/alerts/${a.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ acknowledged: true }),
    });
    a.acknowledged = true;
  }
  renderAlertsPage();
  renderRecentAlerts();
  updateNotifBadge();
  showToast('success', 'All Acknowledged', `${unacked.length} alerts resolved.`);
}

function updateNotifBadge() {
  const count = STATE.alerts.filter(a => !a.acknowledged).length;
  document.getElementById('notifCount').textContent = count;
  document.getElementById('notifCount').style.display = count > 0 ? 'flex' : 'none';
  document.getElementById('alertBadge').textContent = count;
}

async function simulateAlert() {
  const models = [...new Set(STATE.outputs.map(o => o.model_name))];
  const model  = models[Math.floor(Math.random() * models.length)] || 'GPT-4-Turbo';
  const types  = ['anomaly', 'critical_failure', 'threshold_breach', 'system_error'];
  const sevs   = ['Medium', 'High', 'Critical'];
  const msgs   = [
    `${model}: Accuracy dropped below threshold. Immediate review required.`,
    `${model}: Latency spike detected — ${Math.floor(Math.random()*3000+800)}ms.`,
    `${model}: Error rate exceeded ${Math.floor(Math.random()*30+15)}% threshold.`,
    `${model}: Confidence score critically low — possible hallucination.`,
  ];
  const sev  = sevs[Math.floor(Math.random() * sevs.length)];
  const type = types[Math.floor(Math.random() * types.length)];
  const msg  = msgs[Math.floor(Math.random() * msgs.length)];
  const email = document.getElementById('alertEmail')?.value || 'admin@enterprise.com';

  try {
    const res = await fetch('tables/alerts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alert_type: type, model_name: model, message: msg, severity: sev, email_to: email, acknowledged: false }),
    });
    const created = await res.json();
    STATE.alerts.push(created);
    renderAlertsPage();
    renderRecentAlerts();
    updateNotifBadge();
    showToast('warning', 'Alert Fired 🚩', msg);
    if (document.getElementById('enableEmailAlerts')?.checked) showEmailModal(created);
  } catch (err) {
    showToast('error', 'Error', 'Could not create alert.');
  }
}

function resendEmail(id) {
  const a = STATE.alerts.find(x => x.id === id);
  if (a) showEmailModal(a);
}

// ─── LOGS PAGE ────────────────────────────────────────
function renderLogsPage() {
  const tbody = document.getElementById('logTableBody');
  let outputs = [...STATE.outputs].reverse();

  const mf = document.getElementById('logModelFilter')?.value;
  const sf = document.getElementById('logStatusFilter')?.value;
  if (mf && mf !== 'all') outputs = outputs.filter(o => o.model_name === mf);
  if (sf && sf !== 'all') outputs = outputs.filter(o => detectStatus(o) === sf);

  if (!outputs.length) {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:40px">No records found</td></tr>';
    return;
  }

  tbody.innerHTML = outputs.map(o => {
    const status = detectStatus(o);
    const risk   = computeRisk(o);
    const ts     = o.created_at ? new Date(o.created_at).toLocaleString() : '—';
    return `
      <tr>
        <td>${ts}</td>
        <td style="font-weight:600;color:var(--text-primary)">${o.model_name}</td>
        <td style="color:${o.accuracy < STATE.thresholds.minAccuracy ? 'var(--red)' : 'var(--green)'};font-weight:600">${o.accuracy?.toFixed(1)}%</td>
        <td style="color:${o.latency > STATE.thresholds.maxLatency ? 'var(--orange)' : 'inherit'}">${o.latency}ms</td>
        <td style="color:${o.error_rate > STATE.thresholds.maxErrorRate ? 'var(--red)' : 'inherit'}">${o.error_rate?.toFixed(1)}%</td>
        <td>${o.confidence?.toFixed(2)}</td>
        <td><span class="status-pill ${status}">${status.charAt(0).toUpperCase()+status.slice(1)}</span></td>
        <td><span class="risk-pill ${risk}">${risk}</span></td>
        <td class="output-cell" title="${escHtml(o.raw_output || '')}">${escHtml(o.raw_output || '—')}</td>
      </tr>`;
  }).join('');
}

function filterLogs() { renderLogsPage(); }

async function clearLogs() {
  if (!confirm('Clear all local log view? (API data remains)')) return;
  STATE.outputs = [];
  renderLogsPage();
  showToast('info', 'Logs Cleared', 'Log view has been cleared.');
}

// ─── UPLOAD / MANUAL ENTRY ────────────────────────────
async function submitManualEntry() {
  const model    = document.getElementById('manualModel').value;
  const accuracy = parseFloat(document.getElementById('manualAccuracy').value);
  const latency  = parseFloat(document.getElementById('manualLatency').value);
  const errorRate= parseFloat(document.getElementById('manualErrorRate').value);
  const confidence = parseFloat(document.getElementById('manualConfidence').value);
  const rawOutput  = document.getElementById('manualRawOutput').value;

  if (!model || isNaN(accuracy) || isNaN(latency) || isNaN(errorRate) || isNaN(confidence)) {
    showToast('error', 'Validation Error', 'Please fill in all required fields.');
    return;
  }
  if (accuracy < 0 || accuracy > 100)    { showToast('error', 'Invalid', 'Accuracy must be 0–100.'); return; }
  if (confidence < 0 || confidence > 1)  { showToast('error', 'Invalid', 'Confidence must be 0–1.'); return; }

  const row = { model_name: model, accuracy, latency, error_rate: errorRate, confidence, raw_output: rawOutput };
  row.status = detectStatus(row);
  row.risk_level = computeRisk(row);
  row.alert_sent = false;

  try {
    const res = await fetch('tables/model_outputs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(row),
    });
    const created = await res.json();
    STATE.outputs.push(created);

    // Auto-alert if anomaly
    if (row.status !== 'normal') {
      await autoCreateAlert(created);
    }

    showToast('success', 'Entry Added', `${model} output submitted. Status: ${row.status}`);
    renderDashboard();
    updateCharts();
    renderModelsPage();
    renderLogsPage();

    // Reset form
    ['manualAccuracy','manualLatency','manualErrorRate','manualConfidence','manualRawOutput']
      .forEach(id => { document.getElementById(id).value = ''; });
  } catch (err) {
    showToast('error', 'Error', 'Could not save entry.');
  }
}

function handleFileUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  processFile(file);
}

function handleFileDrop(event) {
  const file = event.dataTransfer.files[0];
  if (!file) return;
  processFile(file);
}

function processFile(file) {
  if (!file.name.endsWith('.json') && !file.name.endsWith('.csv')) {
    showToast('error', 'Unsupported', 'Only .json and .csv files are supported.');
    return;
  }
  const reader = new FileReader();
  reader.onload = async e => {
    try {
      let entries = [];
      if (file.name.endsWith('.json')) {
        const data = JSON.parse(e.target.result);
        entries = Array.isArray(data) ? data : [data];
      } else {
        // basic CSV parse
        const lines = e.target.result.trim().split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        entries = lines.slice(1).map(line => {
          const vals = line.split(',');
          return Object.fromEntries(headers.map((h, i) => [h, isNaN(vals[i]) ? vals[i]?.trim() : parseFloat(vals[i])]));
        });
      }

      let added = 0;
      for (const entry of entries) {
        const row = {
          model_name:  entry.model_name || entry.model || 'Unknown',
          accuracy:    parseFloat(entry.accuracy) || 0,
          latency:     parseFloat(entry.latency) || 0,
          error_rate:  parseFloat(entry.error_rate || entry.errorRate) || 0,
          confidence:  parseFloat(entry.confidence) || 0,
          raw_output:  entry.raw_output || JSON.stringify(entry),
        };
        row.status     = detectStatus(row);
        row.risk_level = computeRisk(row);
        row.alert_sent = false;
        const res = await fetch('tables/model_outputs', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(row),
        });
        const created = await res.json();
        STATE.outputs.push(created);
        if (row.status !== 'normal') await autoCreateAlert(created);
        added++;
      }

      showToast('success', 'File Imported', `${added} entries imported from ${file.name}.`);
      renderDashboard(); updateCharts(); renderModelsPage(); renderLogsPage();
    } catch (err) {
      showToast('error', 'Parse Error', 'Could not parse file. Check format.');
    }
  };
  reader.readAsText(file);
}

// ─── STREAM SIMULATOR ─────────────────────────────────
function startStream() {
  const model        = document.getElementById('streamModel').value;
  const interval     = parseInt(document.getElementById('streamInterval').value) * 1000 || 3000;
  const anomalyRate  = parseInt(document.getElementById('streamAnomalyRate').value) || 20;

  document.getElementById('streamStartBtn').disabled = true;
  document.getElementById('streamStopBtn').disabled  = false;
  document.getElementById('streamDot').classList.add('active');
  document.getElementById('streamStatusLabel').textContent = `Streaming ${model}…`;

  STATE.streamTimer = setInterval(async () => {
    const isAnomaly  = Math.random() * 100 < anomalyRate;
    const isCritical = isAnomaly && Math.random() < 0.3;
    const accuracy   = isCritical ? rand(40,60) : isAnomaly ? rand(60,79) : rand(82,99);
    const latency    = isCritical ? rand(1200,2500) : isAnomaly ? rand(800,1200) : rand(200,700);
    const errorRate  = isCritical ? rand(20,45) : isAnomaly ? rand(10,20) : rand(0,8);
    const confidence = isCritical ? rand(25,55)/100 : isAnomaly ? rand(55,70)/100 : rand(75,99)/100;

    const row = {
      model_name: model, accuracy, latency, error_rate: errorRate, confidence,
      raw_output: JSON.stringify({ response: isAnomaly ? 'ANOMALY DETECTED' : 'OK', tokens: Math.floor(rand(100,1000)) }),
    };
    row.status     = detectStatus(row);
    row.risk_level = computeRisk(row);
    row.alert_sent = false;

    try {
      const res = await fetch('tables/model_outputs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(row),
      });
      const created = await res.json();
      STATE.outputs.push(created);

      appendStreamEntry(created);
      if (row.status !== 'normal') await autoCreateAlert(created);

      renderDashboard(); updateCharts(); renderModelsPage(); renderLogsPage();
    } catch {}
  }, interval);
}

function stopStream() {
  clearInterval(STATE.streamTimer);
  document.getElementById('streamStartBtn').disabled = false;
  document.getElementById('streamStopBtn').disabled  = true;
  document.getElementById('streamDot').classList.remove('active');
  document.getElementById('streamStatusLabel').textContent = 'Stopped';
  showToast('info', 'Stream Stopped', 'Live stream has been stopped.');
}

function appendStreamEntry(row) {
  const entries = document.getElementById('streamEntries');
  const ts = new Date().toLocaleTimeString();
  const div = document.createElement('div');
  div.className = `stream-entry ${row.status}`;
  div.textContent = `[${ts}] ${row.model_name} | acc:${row.accuracy.toFixed(1)}% lat:${row.latency}ms err:${row.error_rate.toFixed(1)}% → ${row.status.toUpperCase()}`;
  entries.appendChild(div);
  entries.scrollTop = entries.scrollHeight;
}

// ─── AUTO ALERT ───────────────────────────────────────
async function autoCreateAlert(row) {
  const sev = row.risk_level === 'High' ? 'Critical' : row.risk_level === 'Medium' ? 'High' : 'Medium';
  const type = row.status === 'critical' ? 'critical_failure' : 'anomaly';
  const msg = `${row.model_name}: ${row.status === 'critical' ? 'CRITICAL' : 'Anomaly'} — acc:${row.accuracy.toFixed(1)}%, err:${row.error_rate.toFixed(1)}%, lat:${row.latency}ms`;
  const email = document.getElementById('alertEmail')?.value || 'admin@enterprise.com';
  try {
    const res = await fetch('tables/alerts', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alert_type: type, model_name: row.model_name, message: msg, severity: sev, email_to: email, acknowledged: false }),
    });
    const created = await res.json();
    STATE.alerts.push(created);
    renderAlertsPage();
    renderRecentAlerts();
    updateNotifBadge();
    if (document.getElementById('enableEmailAlerts')?.checked) showEmailModal(created);
  } catch {}
}

// ─── THRESHOLDS ───────────────────────────────────────
function updateThresholdDisplay(input, displayId, suffix) {
  document.getElementById(displayId).textContent = parseFloat(input.value).toFixed(suffix === '' ? 2 : 0) + suffix;
}

function saveThresholds() {
  STATE.thresholds.minAccuracy   = parseFloat(document.getElementById('threshAccuracy').value);
  STATE.thresholds.maxLatency    = parseFloat(document.getElementById('threshLatency').value);
  STATE.thresholds.maxErrorRate  = parseFloat(document.getElementById('threshErrorRate').value);
  STATE.thresholds.minConfidence = parseFloat(document.getElementById('threshConfidence').value);
  STATE.alertEmail = document.getElementById('alertEmail')?.value || 'admin@enterprise.com';
  showToast('success', 'Thresholds Saved', 'Anomaly detection parameters updated.');
  updateCharts();
  renderDashboard();
  renderModelsPage();
  renderLogsPage();
}

// ─── EMAIL MODAL ──────────────────────────────────────
function showEmailModal(alert) {
  const body = document.getElementById('emailModalBody');
  const ts = new Date().toLocaleString();
  body.innerHTML = `
    <div class="email-preview">
      <div class="email-preview-header"><i class="fas fa-envelope-open-text"></i> Simulated Email Alert</div>
      <div class="email-body">
        <strong>From:</strong> alerts@aifailguard.io<br/>
        <strong>To:</strong> ${escHtml(alert.email_to || 'admin@enterprise.com')}<br/>
        <strong>Date:</strong> ${ts}<br/>
        <strong>Subject:</strong> 🚨 AIFailGuard — ${escHtml(alert.severity || '')} Alert: ${escHtml(alert.model_name || '')}<br/><br/>
        <em style="color:var(--text-secondary)">${escHtml(alert.message || '')}</em><br/><br/>
        <span style="font-size:11px;color:var(--text-muted)">
          Alert Type: ${escHtml(alertTypeLabel(alert.alert_type))}<br/>
          Severity: ${escHtml(alert.severity || '')}<br/>
          Reference ID: ${escHtml(alert.id || '')}<br/>
          — AIFailGuard Enterprise Monitoring
        </span>
      </div>
    </div>`;
  document.getElementById('emailModal').style.display = 'flex';
}
function closeEmailModal() { document.getElementById('emailModal').style.display = 'none'; }

// ─── EXPORT ───────────────────────────────────────────
function exportReport() {
  const outputs = STATE.outputs;
  const risk    = computeSystemRisk(outputs);
  const report  = {
    generated: new Date().toISOString(),
    system_risk: risk,
    total_outputs: outputs.length,
    anomalies: outputs.filter(o => detectStatus(o) !== 'normal').length,
    models: [...new Set(outputs.map(o => o.model_name))].map(m => {
      const mo = outputs.filter(o => o.model_name === m);
      return { model: m, avg_accuracy: avg(mo.map(o => o.accuracy)).toFixed(2), avg_latency: avg(mo.map(o => o.latency)).toFixed(0), avg_error_rate: avg(mo.map(o => o.error_rate)).toFixed(2), risk: computeSystemRisk(mo).level };
    }),
    alerts: STATE.alerts.length,
    unacknowledged_alerts: STATE.alerts.filter(a => !a.acknowledged).length,
  };
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `aifailguard_report_${Date.now()}.json`;
  a.click(); URL.revokeObjectURL(url);
  showToast('success', 'Report Exported', 'JSON report downloaded.');
}

// ─── SCAN ─────────────────────────────────────────────
function runScan() {
  document.getElementById('scanModal').style.display = 'flex';
  document.getElementById('scanResults').style.display = 'none';
  ['scan1','scan2','scan3','scan4','scan5'].forEach(id => {
    const el = document.getElementById(id);
    if (id === 'scan1') { el.className = 'scan-step'; el.querySelector('i').className = 'fas fa-circle-notch fa-spin'; }
    else { el.className = 'scan-step pending'; el.querySelector('i').className = 'fas fa-circle'; }
  });

  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  (async () => {
    await delay(600); completeScanStep('scan1','scan2');
    await delay(700); completeScanStep('scan2','scan3');
    await delay(600); completeScanStep('scan3','scan4');
    await delay(500); completeScanStep('scan4','scan5');
    await delay(400);
    const el5 = document.getElementById('scan5');
    el5.className = 'scan-step done'; el5.querySelector('i').className = 'fas fa-check-circle';

    const risk = computeSystemRisk(STATE.outputs);
    const anomalies = STATE.outputs.filter(o => detectStatus(o) !== 'normal');
    const scanResults = document.getElementById('scanResults');
    scanResults.innerHTML = `
      <h4 style="font-size:13px;margin-bottom:12px;color:var(--text-secondary)">Scan Results</h4>
      <div class="scan-result-item"><i class="fas fa-circle-check" style="color:var(--green)"></i> ${STATE.outputs.length} outputs analyzed</div>
      <div class="scan-result-item"><i class="fas fa-triangle-exclamation" style="color:var(--orange)"></i> ${anomalies.length} anomalies found</div>
      <div class="scan-result-item"><i class="fas fa-shield-alt" style="color:${risk.level==='High'?'var(--red)':risk.level==='Medium'?'var(--orange)':'var(--green)'}"></i> System Risk: ${risk.level} (${risk.score}/100)</div>
      <div class="scan-result-item"><i class="fas fa-bell" style="color:var(--red)"></i> ${STATE.alerts.filter(a=>!a.acknowledged).length} unacknowledged alerts</div>`;
    scanResults.style.display = 'block';
  })();
}

function completeScanStep(doneId, nextId) {
  const done = document.getElementById(doneId);
  done.className = 'scan-step done'; done.querySelector('i').className = 'fas fa-check-circle';
  if (nextId) {
    const next = document.getElementById(nextId);
    next.className = 'scan-step'; next.querySelector('i').className = 'fas fa-circle-notch fa-spin';
  }
}

// ─── TOAST ────────────────────────────────────────────
function showToast(type, title, message) {
  const container = document.getElementById('toastContainer');
  const icons = { success: 'fa-circle-check', error: 'fa-circle-xmark', warning: 'fa-triangle-exclamation', info: 'fa-circle-info' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <i class="fas ${icons[type] || 'fa-info'} toast-icon"></i>
    <div class="toast-body"><div class="toast-title">${title}</div><div class="toast-message">${message}</div></div>
    <i class="fas fa-times toast-close" onclick="this.parentElement.remove()"></i>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 5000);
}

// ─── HELPERS ──────────────────────────────────────────
function avg(arr) { return arr.length ? arr.reduce((a,b) => a + (b||0), 0) / arr.length : 0; }
function rand(min, max) { return Math.round(Math.random() * (max - min) + min); }
function escHtml(str) { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1,3), 16);
  const g = parseInt(hex.slice(3,5), 16);
  const b = parseInt(hex.slice(5,7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}
function severityIcon(sev) {
  return { Critical: '🚨', High: '🔴', Medium: '🟠', Low: '🟡' }[sev] || '⚪';
}
function severityFAIcon(sev) {
  return { Critical: 'fas fa-skull-crossbones', High: 'fas fa-exclamation-triangle', Medium: 'fas fa-exclamation-circle', Low: 'fas fa-info-circle' }[sev] || 'fas fa-flag';
}
function alertTypeLabel(type) {
  return { anomaly: 'Anomaly Detected', critical_failure: 'Critical Failure', threshold_breach: 'Threshold Breach', system_error: 'System Error' }[type] || type;
}
